class Robot_View:
    def show_position(self, elevation, rotation, length):
      print(f"Posición Robot >> Elevación: {elevation}, Rotación: {rotation}, Distancia: {length}")
