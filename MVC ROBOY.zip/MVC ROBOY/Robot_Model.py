class RobotModel:
    def __init__(self):
        self.elevation = 0
        self.rotation = 0
        self.length = 0

    def move(self, elevation, rotation, length):
        self.elevation = elevation
        self.rotation = rotation
        self.length = length
