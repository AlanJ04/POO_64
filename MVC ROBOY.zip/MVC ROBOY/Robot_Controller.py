class RobotController:
    def __init__(self, model, view):
        self.model = model
        self.view = view

    def move_robot(self, elevation, rotation, length):
        self.model.move(elevation, rotation, length)
        self.view.show_position(self.model.elevation, self.model.rotation, self.model.length)