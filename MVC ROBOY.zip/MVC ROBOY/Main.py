import Robot_Controller as control 
import Robot_Model as model
import Robot_View as view

if __name__ == "__main__":
    model1 = model.RobotModel()
    view1 = view.Robot_View()
    control1 = control.RobotController(model1, view1)

    varelec =  4
    while varelec != 0:
        if varelec == 1:
            model1.elevation = int(input("Ingrese la nueva elevación:"))
            control1.view.show_position(model1.elevation, model1.rotation, model1.length)
        elif varelec == 2:
            print("Ingrese la nueva rotación:")
            model1.rotation = int(input("Ingrese la nueva rotación"))
            control1.view.show_position(model1.elevation, model1.rotation, model1.length)
        elif varelec == 3:
            print("Ingrese la nueva distancia:")
            model1.length = int(input(""))
            control1.view.show_position(model1.elevation, model1.rotation, model1.length)
        elif varelec == 4:
            print("Ingrese las nuevas indicacciones:")
            x= int(input("Ingrese la nueva elevación:"))
            y= int(input("Ingrese la nueva rotación:"))
            z= int(input("Ingrese la nueva distancia:"))
            control1.move_robot(x, y, z)
        elif varelec == 0:
            print("Programa finalizado...")
        print("-"*50)
        print ("1.Modificar Elevación \n2.Modificar Rotación\n3.Modificar Distancia\n4.Cambiar todas las coordenadas\n0.Salir")
        print("-"*50)

        varelec = int(input())